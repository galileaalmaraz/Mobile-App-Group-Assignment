package com.example.angles;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "AnglesDB";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_ANGLE = "angle";
    private static final String ID = "id";
    private static final String TYPE = "type";
    private static final String NAME = "name";
    private static final String PRICE = "price";

    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCreate = "create table " + TABLE_ANGLE + " ( " + ID;
        sqlCreate += " integer primary key autoincrement, " + TYPE;
        sqlCreate += " number, " + NAME;
        sqlCreate += " text, " + PRICE + " number )";


        db.execSQL(sqlCreate);
    }

    public void insertAngle(Angles angle){
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlInsert = "insert into " + TABLE_ANGLE + " values (null, '" +
                angle.getType() + "','" + angle.getName() + "','" + angle.getPrice() + "')";

        db.execSQL(sqlInsert);
        db.close();
    }

    public ArrayList<Angles> selectAll(){
        String sqlQuery = "select * from " + TABLE_ANGLE;
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(sqlQuery, null);

        ArrayList<Angles> angles = new ArrayList<>();

        while(cursor.moveToNext()){
            Angles currentAngle = new Angles(Integer.parseInt(cursor.getString(0)),
                    cursor.getInt(1), cursor.getString(2), cursor.getDouble(3));
            angles.add(currentAngle);
        }
        db.close();
        return angles;
    }

    public ArrayList<Angles> selectItem(int type){
        String sqlQuery = "select * from " + TABLE_ANGLE + " where " + TYPE + " = " + type;
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(sqlQuery, null);

        ArrayList<Angles> angles = new ArrayList<>();

        while(cursor.moveToNext()){
            Angles currentAngle = new Angles(Integer.parseInt(cursor.getString(0)),
                    cursor.getInt(1), cursor.getString(2), cursor.getDouble(3));
            angles.add(currentAngle);
        }
        db.close();
        return angles;
    }

    public void deleteById(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlDelete = "delete from " + TABLE_ANGLE + " where " + ID + " = " + id;
        db.execSQL(sqlDelete);
        db.close();
    }

    public void updateById(int id, String type, String name, double price){
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlUpdate = "update " + TABLE_ANGLE + " set " + TYPE + " = '" + type + "', ";
        sqlUpdate += NAME + " = '" + name + "', ";
        sqlUpdate += PRICE + " = '" + price + "' where " + ID + " = " + id;

        db.execSQL(sqlUpdate);
        db.close();
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion ) {
        // Drop old table if it exists
        db.execSQL( "drop table if exists " + TABLE_ANGLE );
        // Re-create tables
        onCreate( db );
    }

    public void addToCart() {

    }
}