package com.example.angles;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOError;


public class AddActivity extends AppCompatActivity {

    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        dbManager = new DatabaseManager(this);
    }

    public void add (View v){
        EditText typeET = findViewById(R.id.input_type);
        int typeInt = Integer.parseInt(String.valueOf(typeET.getText()));

        EditText nameET = findViewById(R.id.input_name);
        String nameString = nameET.getText().toString();

        EditText priceET = findViewById(R.id.input_price);
        Double priceDouble = Double.parseDouble(String.valueOf(priceET.getText()));


        Angles angle = new Angles(0, typeInt, nameString, priceDouble);
        dbManager.insertAngle(angle);
        Toast.makeText(this,  nameString + " is added to the DB table.", Toast.LENGTH_LONG).show();



        // clear edit text
        typeET.setText("");
        nameET.setText("");
        priceET.setText("");
    }

    public void goBack (View v){
        this.finish();
    }
}