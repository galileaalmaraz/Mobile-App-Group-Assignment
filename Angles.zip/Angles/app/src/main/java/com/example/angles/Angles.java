package com.example.angles;


import java.text.DecimalFormat;

public class Angles {
    private int id;
    private int type;
    private String name;
    private double price;

    public final DecimalFormat MONEY = new DecimalFormat( "$#,##0.00" );


    public Angles( int newId, int newType, String newName, double newPrice) {
        setId( newId );
        setType( newType );
        setName( newName );
        setPrice( newPrice );
    }

    public void setId( int newId ) {
        id = newId;
    }

    public void setType( int newType ) {
        type = newType;
    }

    public void setName( String newName ) {
        name = newName;
    }

    public void setPrice( double newPrice ) {
        price = newPrice;
    }

    public int getId() {
        return id;
    }

    public int getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String toString(){
        return ( name + ": " + MONEY.format(price));
    }
}
