package com.example.angles;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOError;


public class AddActivity extends AppCompatActivity {

    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        dbManager = new DatabaseManager(this);
    }

    public void add (View v){
        EditText typeET = findViewById(R.id.input_type);
        String typeString = typeET.getText().toString();

        EditText nameET = findViewById(R.id.input_name);
        String nameString = nameET.getText().toString();

        EditText priceET = findViewById(R.id.input_price);
        String priceString = priceET.getText().toString();

        int type = Integer.parseInt(typeString);
        Double price = Double.parseDouble(priceString);
        Angles angle = new Angles(0, type, nameString, price);
        dbManager.insertAngle(angle);
        Toast.makeText(this,  nameString + " is added to the Catalog.", Toast.LENGTH_LONG).show();



        // clear edit text
        typeET.setText("");
        nameET.setText("");
        priceET.setText("");
    }

    public void goBack (View v){
        this.finish();
    }
}