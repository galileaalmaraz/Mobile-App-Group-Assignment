package com.example.angles.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.angles.MainActivity;
import com.example.angles.R;
import com.example.angles.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private Button btnLogIn, shirtsBtn, pantsBtn, shoesBtn;
    public HomeFragment(){};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }


    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        btnLogIn = view.findViewById(R.id.logInBtn);
        shoesBtn = view.findViewById(R.id.action_shoes);
        shirtsBtn = view.findViewById(R.id.action_shirts);
        pantsBtn = view.findViewById(R.id.action_pants);


        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity) getActivity()).goLogIn();
            }
        });

        shoesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity) getActivity()).toShoe();
            }
        });

        shirtsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity) getActivity()).toShirt();
            }
        });

        pantsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity) getActivity()).toPant();
            }
        });




    }






    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}