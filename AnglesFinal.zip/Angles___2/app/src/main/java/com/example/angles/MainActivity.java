package com.example.angles;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.angles.ui.dashboard.DashboardFragment;
import com.example.angles.ui.dashboard.SignUpFragment;
import com.example.angles.ui.home.HomeFragment;
import com.example.angles.ui.home.PantsActivity;
import com.example.angles.ui.home.ShirtsActivity;
import com.example.angles.ui.home.ShoesActivity;
import com.example.angles.ui.notifications.CheckOutFragment;
import com.example.angles.ui.notifications.NotificationsFragment;
import com.example.angles.ui.notifications.ThankYouFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.angles.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    public MainActivity(){};

    FragmentManager fragmentmanager = getSupportFragmentManager();
    Fragment signup = new SignUpFragment();
    Fragment checkOut = new CheckOutFragment();
    Fragment logIn = new DashboardFragment();
    Fragment cart = new NotificationsFragment();
    Fragment main = new HomeFragment();
    Fragment Lpage = new ThankYouFragment();
    Fragment shirtPage = new ShirtsActivity();
    Fragment pantsPage = new PantsActivity();
    Fragment shoesPage = new ShoesActivity();
    private ActivityMainBinding binding;
    private Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_add) {
            Intent addintent = new Intent(this, AddActivity.class);
            this.startActivity(addintent);
            return true;
        }

        if (id == R.id.action_shirts) {
            Intent shirtintent = new Intent(this, Catalog.class);
            this.startActivity(shirtintent);
            return true;
        }

//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_delete) {
//            Intent deleteintent = new Intent(this, DeleteActivity.class);
//            this.startActivity(deleteintent);
//            return true;
//        }
//
////        noinspection SimplifiableIfStatement
//        if (id == R.id.action_update) {
//            Intent updateintent = new Intent(this, UpdateActivity.class);
//            this.startActivity(updateintent);
//            return true;
//        }
//
//        if (id == R.id.action_search) {
//            Intent searchintent = new Intent(this, SearchActivity.class);
//            this.startActivity(searchintent);
//            return true;
//        }
        return super.onOptionsItemSelected(item);
    }

    public void goLogIn(){
        fragmentmanager.beginTransaction().replace(R.id.container, logIn).commit();
    }

    public void tosignUp(){
        fragmentmanager.beginTransaction().replace(R.id.container, signup).commit();
    }

    public void tocheckOut(){
        fragmentmanager.beginTransaction().replace(R.id.container, checkOut).commit();
    }

    public void toCart(){
        fragmentmanager.beginTransaction().replace(R.id.container, cart).commit();
    }


    public void toHome(){
        fragmentmanager.beginTransaction().replace(R.id.container, main).commit();
    }


    public void lastPage(){
        fragmentmanager.beginTransaction().replace(R.id.container, Lpage).commit();
    }





    public void toShirt(){
        fragmentmanager.beginTransaction().replace(R.id.container, shirtPage).commit();
    }


    public void toPant(){
        fragmentmanager.beginTransaction().replace(R.id.container, pantsPage).commit();
    }


    public void toShoe(){
        fragmentmanager.beginTransaction().replace(R.id.container, shoesPage).commit();
    }


//    @Override
//    public boolean onSupportNavigateUp() {
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
//        return NavigationUI.navigateUp(navController, appBarConfiguration)
//                || super.onSupportNavigateUp();
//    }

}