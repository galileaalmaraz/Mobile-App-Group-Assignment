package com.example.angles.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.angles.MainActivity;
import com.example.angles.R;
import com.example.angles.databinding.FragmentDashboardBinding;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private FragmentDashboardBinding binding;
    private Button btnSignUp, toHomeBtn, toCartBtn;

    public DashboardFragment(){};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }


        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        btnSignUp = view.findViewById(R.id.signUpBtn);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity)getActivity()).tosignUp();
            }
        });

        toCartBtn = view.findViewById(R.id.goCartBtn);
            toCartBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //do code
                    ((MainActivity)getActivity()).toCart();
                }
            });


            toHomeBtn = view.findViewById(R.id.goHomeBtn);
            toHomeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //do code
                    ((MainActivity)getActivity()).toHome();
                }
            });

    }


/*
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        btnSignUp = (Button) findViewById(R.id.signup);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentStore = new Intent();
                startActivity(intentStore);
            }
        });
    }
 */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}