package com.example.angles.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.angles.MainActivity;
import com.example.angles.R;
import com.example.angles.databinding.FragmentDashboardBinding;

public class SignUpFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private FragmentDashboardBinding binding;
    private Button end;

    public SignUpFragment(){};

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_sign_up, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        end = view.findViewById(R.id.goBackBtn);
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity)getActivity()).goLogIn();
            }
        });

    }


    public void add(View v) {
        EditText ETEmail = v.findViewById(R.id.email);
        String emailText = ETEmail.getText().toString();

        EditText ETPassword = v.findViewById(R.id.password);
        String passwordText = ETPassword.getText().toString();

        EditText ETFirst = v.findViewById(R.id.firstname);
        String firstText = ETFirst.getText().toString();

        EditText ETLast = v.findViewById(R.id.lastname);
        String lastText = ETLast.getText().toString();

    }

}