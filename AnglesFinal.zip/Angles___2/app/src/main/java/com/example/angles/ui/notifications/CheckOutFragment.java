package com.example.angles.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.angles.MainActivity;
import com.example.angles.R;

public class CheckOutFragment extends Fragment {
    public CheckOutFragment(){};
    private Button completeBtn, viewCartBtn;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.checkout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        viewCartBtn = view.findViewById(R.id.backCartBtn);

        viewCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity)getActivity()).toCart();
            }
        });

        completeBtn = view.findViewById(R.id.payBtn);

        completeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do code
                ((MainActivity)getActivity()).lastPage();
            }
        });



    }

}
